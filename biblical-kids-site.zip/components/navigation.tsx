"use client"

import Link from "next/link"
import { BookOpen, Video, Palette, Home, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"

export function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const navItems = [
    { href: "/", label: "Inicio", icon: Home },
    { href: "/historias", label: "Historias", icon: BookOpen },
    { href: "/videos", label: "Videos", icon: Video },
    { href: "/colorear", label: "Colorear", icon: Palette },
  ]

  return (
    <nav className="sticky top-0 z-50 border-b-4 border-blue-200 bg-white shadow-lg">
      <div className="container mx-auto max-w-6xl px-4">
        <div className="flex h-20 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="rounded-full bg-gradient-to-br from-blue-400 to-blue-600 p-3 group-hover:scale-110 transition-transform">
              <BookOpen className="h-8 w-8 text-white" />
            </div>
            <span className="text-2xl font-bold text-blue-600 hidden sm:inline">Historias Bíblicas</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-2">
            {navItems.map((item) => {
              const Icon = item.icon
              return (
                <Link key={item.href} href={item.href}>
                  <Button
                    variant="ghost"
                    size="lg"
                    className="text-lg font-semibold text-gray-700 hover:bg-blue-100 hover:text-blue-600 rounded-full gap-2"
                  >
                    <Icon className="h-5 w-5" />
                    {item.label}
                  </Button>
                </Link>
              )
            })}
          </div>

          {/* Mobile Menu Button */}
          <Button variant="ghost" size="lg" className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="h-8 w-8 text-blue-600" /> : <Menu className="h-8 w-8 text-blue-600" />}
          </Button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t-2 border-blue-100 py-4">
            <div className="flex flex-col gap-2">
              {navItems.map((item) => {
                const Icon = item.icon
                return (
                  <Link key={item.href} href={item.href} onClick={() => setMobileMenuOpen(false)}>
                    <Button
                      variant="ghost"
                      size="lg"
                      className="w-full justify-start text-xl font-semibold text-gray-700 hover:bg-blue-100 hover:text-blue-600 rounded-xl gap-3 py-6"
                    >
                      <Icon className="h-6 w-6" />
                      {item.label}
                    </Button>
                  </Link>
                )
              })}
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
