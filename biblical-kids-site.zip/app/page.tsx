import { BookOpen, Video, Palette, Sparkles } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-400 via-blue-300 to-cyan-200 px-4 py-16 md:py-24">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 h-32 w-32 rounded-full bg-yellow-300 animate-float" />
          <div
            className="absolute top-40 right-20 h-24 w-24 rounded-full bg-orange-300 animate-float"
            style={{ animationDelay: "1s" }}
          />
          <div
            className="absolute bottom-20 left-1/4 h-28 w-28 rounded-full bg-green-300 animate-float"
            style={{ animationDelay: "2s" }}
          />
        </div>

        <div className="container relative mx-auto max-w-6xl text-center">
          <div className="mb-6 flex justify-center">
            <Sparkles className="h-16 w-16 text-yellow-400 animate-bounce-gentle" />
          </div>

          <h1 className="mb-6 text-5xl font-bold text-white md:text-7xl text-balance drop-shadow-lg">
            ¡Historias Bíblicas para Niños!
          </h1>

          <p className="mb-8 text-xl text-white md:text-2xl text-balance max-w-3xl mx-auto leading-relaxed drop-shadow">
            Descubre historias maravillosas, videos divertidos y libros para colorear
          </p>

          <div className="flex flex-wrap justify-center gap-4">
            <Button
              size="lg"
              className="bg-yellow-400 text-gray-900 hover:bg-yellow-500 text-xl px-8 py-6 rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-105"
            >
              ¡Empezar a Explorar!
            </Button>
          </div>
        </div>
      </section>

      {/* Main Navigation Cards */}
      <section className="px-4 py-16 md:py-20">
        <div className="container mx-auto max-w-6xl">
          <h2 className="mb-12 text-center text-4xl font-bold text-gray-800 md:text-5xl">¿Qué Quieres Hacer Hoy?</h2>

          <div className="grid gap-8 md:grid-cols-3">
            {/* Biblical Stories Card */}
            <Link href="/historias" className="group">
              <Card className="h-full overflow-hidden border-4 border-blue-200 bg-gradient-to-br from-blue-50 to-blue-100 p-8 transition-all hover:scale-105 hover:shadow-2xl hover:border-blue-400">
                <div className="mb-6 flex justify-center">
                  <div className="rounded-full bg-blue-400 p-6 group-hover:animate-bounce-gentle">
                    <BookOpen className="h-16 w-16 text-white" />
                  </div>
                </div>

                <h3 className="mb-4 text-center text-3xl font-bold text-blue-900">Historias Bíblicas</h3>

                <p className="text-center text-lg text-blue-800 leading-relaxed">
                  Lee historias increíbles de la Biblia con ilustraciones hermosas
                </p>
              </Card>
            </Link>

            {/* Videos Card */}
            <Link href="/videos" className="group">
              <Card className="h-full overflow-hidden border-4 border-green-200 bg-gradient-to-br from-green-50 to-green-100 p-8 transition-all hover:scale-105 hover:shadow-2xl hover:border-green-400">
                <div className="mb-6 flex justify-center">
                  <div className="rounded-full bg-green-400 p-6 group-hover:animate-bounce-gentle">
                    <Video className="h-16 w-16 text-white" />
                  </div>
                </div>

                <h3 className="mb-4 text-center text-3xl font-bold text-green-900">Videos Divertidos</h3>

                <p className="text-center text-lg text-green-800 leading-relaxed">
                  Mira videos animados de tus historias favoritas
                </p>
              </Card>
            </Link>

            {/* Coloring Books Card */}
            <Link href="/colorear" className="group">
              <Card className="h-full overflow-hidden border-4 border-orange-200 bg-gradient-to-br from-orange-50 to-orange-100 p-8 transition-all hover:scale-105 hover:shadow-2xl hover:border-orange-400">
                <div className="mb-6 flex justify-center">
                  <div className="rounded-full bg-orange-400 p-6 group-hover:animate-bounce-gentle">
                    <Palette className="h-16 w-16 text-white" />
                  </div>
                </div>

                <h3 className="mb-4 text-center text-3xl font-bold text-orange-900">Libros para Colorear</h3>

                <p className="text-center text-lg text-orange-800 leading-relaxed">
                  Descarga y colorea dibujos de historias bíblicas
                </p>
              </Card>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Section */}
      <section className="bg-gradient-to-r from-yellow-100 via-orange-100 to-pink-100 px-4 py-16">
        <div className="container mx-auto max-w-6xl text-center">
          <h2 className="mb-6 text-4xl font-bold text-gray-800 md:text-5xl">¡Aprende y Diviértete!</h2>

          <p className="mb-8 text-xl text-gray-700 leading-relaxed max-w-3xl mx-auto">
            Todas nuestras historias, videos y actividades están diseñadas especialmente para niños como tú. ¡Es seguro,
            divertido y educativo!
          </p>

          <div className="flex flex-wrap justify-center gap-6 text-lg">
            <div className="flex items-center gap-2 bg-white px-6 py-3 rounded-full shadow-md">
              <span className="text-3xl">✨</span>
              <span className="font-semibold text-gray-800">Contenido Seguro</span>
            </div>
            <div className="flex items-center gap-2 bg-white px-6 py-3 rounded-full shadow-md">
              <span className="text-3xl">🎨</span>
              <span className="font-semibold text-gray-800">Muy Divertido</span>
            </div>
            <div className="flex items-center gap-2 bg-white px-6 py-3 rounded-full shadow-md">
              <span className="text-3xl">📚</span>
              <span className="font-semibold text-gray-800">Educativo</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
