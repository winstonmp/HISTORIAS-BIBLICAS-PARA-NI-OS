"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Play, Clock, Star } from "lucide-react"
import { useState } from "react"

const videos = [
  {
    id: "noe-arca-video",
    title: "Noé y el Arca",
    description: "Mira cómo Noé construyó el arca y salvó a los animales",
    thumbnail: "/noah-ark-video-thumbnail-children-animation.jpg",
    duration: "8:45",
    embedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    category: "Antiguo Testamento",
    ageRating: "3+",
  },
  {
    id: "david-goliat-video",
    title: "David y Goliat",
    description: "La increíble historia del valiente David",
    thumbnail: "/david-goliath-video-thumbnail-children-animation.jpg",
    duration: "7:30",
    embedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    category: "Antiguo Testamento",
    ageRating: "4+",
  },
  {
    id: "jonas-ballena-video",
    title: "Jonás y la Ballena",
    description: "Descubre qué pasó cuando Jonás fue tragado por una ballena",
    thumbnail: "/jonah-whale-video-thumbnail-children-animation.jpg",
    duration: "6:20",
    embedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    category: "Antiguo Testamento",
    ageRating: "3+",
  },
  {
    id: "daniel-leones-video",
    title: "Daniel y los Leones",
    description: "Mira cómo Dios protegió a Daniel en el foso de los leones",
    thumbnail: "/daniel-lions-video-thumbnail-children-animation.jpg",
    duration: "9:15",
    embedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    category: "Antiguo Testamento",
    ageRating: "4+",
  },
  {
    id: "nacimiento-jesus-video",
    title: "El Nacimiento de Jesús",
    description: "La hermosa historia de la Navidad",
    thumbnail: "/nativity-video-thumbnail-children-animation.jpg",
    duration: "10:00",
    embedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    category: "Nuevo Testamento",
    ageRating: "3+",
  },
  {
    id: "moises-mar-rojo-video",
    title: "Moisés y el Mar Rojo",
    description: "Ve cómo Moisés abrió el Mar Rojo",
    thumbnail: "/moses-red-sea-video-thumbnail-children-animation.jpg",
    duration: "8:00",
    embedUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    category: "Antiguo Testamento",
    ageRating: "4+",
  },
]

export default function VideosPage() {
  const [selectedVideo, setSelectedVideo] = useState<(typeof videos)[0] | null>(null)
  const [filter, setFilter] = useState<string>("Todos")

  const categories = ["Todos", "Antiguo Testamento", "Nuevo Testamento"]

  const filteredVideos = filter === "Todos" ? videos : videos.filter((video) => video.category === filter)

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50">
      {/* Header */}
      <section className="bg-gradient-to-r from-green-400 to-blue-400 px-4 py-16">
        <div className="container mx-auto max-w-6xl text-center">
          <h1 className="mb-4 text-5xl font-bold text-white md:text-6xl text-balance drop-shadow-lg">
            Videos Divertidos
          </h1>
          <p className="text-xl text-white md:text-2xl text-balance max-w-3xl mx-auto leading-relaxed drop-shadow">
            Mira historias bíblicas animadas
          </p>
        </div>
      </section>

      {/* Video Player Modal */}
      {selectedVideo && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
          onClick={() => setSelectedVideo(null)}
        >
          <div className="w-full max-w-4xl" onClick={(e) => e.stopPropagation()}>
            <Card className="overflow-hidden border-4 border-white bg-white">
              <div className="aspect-video w-full bg-black">
                <iframe
                  src={selectedVideo.embedUrl}
                  title={selectedVideo.title}
                  className="h-full w-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
              <div className="p-6">
                <h3 className="mb-2 text-2xl font-bold text-gray-800">{selectedVideo.title}</h3>
                <p className="mb-4 text-lg text-gray-600">{selectedVideo.description}</p>
                <Button
                  onClick={() => setSelectedVideo(null)}
                  size="lg"
                  className="bg-red-500 text-white hover:bg-red-600 rounded-full"
                >
                  Cerrar Video
                </Button>
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* Filter Buttons */}
      <section className="px-4 py-8">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-wrap justify-center gap-3 mb-8">
            {categories.map((category) => (
              <Button
                key={category}
                onClick={() => setFilter(category)}
                size="lg"
                variant={filter === category ? "default" : "outline"}
                className={`rounded-full text-lg font-semibold ${
                  filter === category
                    ? "bg-green-500 text-white hover:bg-green-600"
                    : "border-2 border-green-400 text-green-600 hover:bg-green-50 bg-transparent"
                }`}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Videos Grid */}
      <section className="px-4 pb-16">
        <div className="container mx-auto max-w-6xl">
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {filteredVideos.map((video) => (
              <Card
                key={video.id}
                className="group h-full overflow-hidden border-4 border-white bg-white shadow-lg transition-all hover:scale-105 hover:shadow-2xl cursor-pointer"
                onClick={() => setSelectedVideo(video)}
              >
                {/* Video Thumbnail */}
                <div className="relative h-48 overflow-hidden bg-gradient-to-br from-green-400 to-blue-400">
                  <img
                    src={video.thumbnail || "/placeholder.svg"}
                    alt={video.title}
                    className="h-full w-full object-cover transition-transform group-hover:scale-110"
                  />

                  {/* Play Button Overlay */}
                  <div className="absolute inset-0 flex items-center justify-center bg-black/30 transition-all group-hover:bg-black/40">
                    <div className="rounded-full bg-white p-4 shadow-lg transition-transform group-hover:scale-110">
                      <Play className="h-12 w-12 text-green-500 fill-green-500" />
                    </div>
                  </div>

                  {/* Duration Badge */}
                  <div className="absolute bottom-3 right-3 flex items-center gap-1 bg-black/70 px-3 py-1 rounded-full">
                    <Clock className="h-4 w-4 text-white" />
                    <span className="text-sm font-semibold text-white">{video.duration}</span>
                  </div>

                  {/* Age Rating Badge */}
                  <div className="absolute top-3 left-3 flex items-center gap-1 bg-white px-3 py-1 rounded-full shadow-md">
                    <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                    <span className="text-sm font-semibold text-gray-700">{video.ageRating}</span>
                  </div>
                </div>

                {/* Video Info */}
                <div className="p-6">
                  <div className="mb-2">
                    <span className="inline-block rounded-full bg-green-100 px-3 py-1 text-sm font-semibold text-green-700">
                      {video.category}
                    </span>
                  </div>
                  <h3 className="mb-3 text-2xl font-bold text-gray-800 group-hover:text-green-600 transition-colors">
                    {video.title}
                  </h3>
                  <p className="text-lg text-gray-600 leading-relaxed">{video.description}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-gradient-to-r from-blue-100 to-purple-100 px-4 py-16">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="mb-4 text-3xl font-bold text-gray-800 md:text-4xl">¿Te Gustaron los Videos?</h2>
          <p className="mb-8 text-xl text-gray-700 leading-relaxed">
            Lee las historias completas o descarga libros para colorear
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button
              size="lg"
              className="bg-blue-500 text-white hover:bg-blue-600 text-xl px-8 py-6 rounded-full shadow-lg"
              onClick={() => (window.location.href = "/historias")}
            >
              Leer Historias
            </Button>
            <Button
              size="lg"
              className="bg-orange-500 text-white hover:bg-orange-600 text-xl px-8 py-6 rounded-full shadow-lg"
              onClick={() => (window.location.href = "/colorear")}
            >
              Libros para Colorear
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
