import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Link from "next/link"
import { ArrowLeft, BookOpen, Heart } from "lucide-react"

const storyContent: Record<
  string,
  {
    title: string
    image: string
    content: string[]
    lesson: string
    verse: string
  }
> = {
  "noe-arca": {
    title: "Noé y el Arca",
    image: "/noah-building-the-ark-with-animals-children-illust.jpg",
    content: [
      "Hace mucho tiempo, vivía un hombre bueno llamado Noé. Dios vio que Noé era una persona especial que siempre hacía lo correcto.",
      "Un día, Dios le habló a Noé y le dijo: 'Voy a enviar una gran lluvia. Necesito que construyas un arca muy grande para salvar a tu familia y a los animales.'",
      "Noé obedeció a Dios. Construyó un arca enorme de madera. Era tan grande como un edificio de tres pisos.",
      "Cuando el arca estuvo lista, llegaron los animales: dos de cada tipo. Vinieron elefantes, jirafas, leones, pájaros, y muchos más. Todos entraron al arca.",
      "Entonces comenzó a llover. Llovió durante 40 días y 40 noches. El agua cubrió toda la tierra, pero Noé, su familia y todos los animales estaban seguros dentro del arca.",
      "Después de muchos días, la lluvia paró. El agua comenzó a bajar. Noé envió una paloma y regresó con una rama de olivo. ¡Había tierra seca!",
      "Finalmente, el arca se detuvo en una montaña. Todos salieron y vieron un hermoso arcoíris en el cielo. Era la promesa de Dios de que nunca más enviaría un diluvio así.",
    ],
    lesson: "Dios cuida de las personas que le obedecen y confían en Él.",
    verse: '"Noé hizo todo tal como Dios se lo mandó." - Génesis 6:22',
  },
  "david-goliat": {
    title: "David y Goliat",
    image: "/young-david-with-sling-facing-giant-goliath-childr.jpg",
    content: [
      "David era un joven pastor que cuidaba ovejas. Era valiente y amaba a Dios con todo su corazón.",
      "Un día, un gigante llamado Goliat desafió al pueblo de Israel. Goliat era muy alto, ¡más alto que dos personas juntas! Todos tenían miedo de él.",
      "David escuchó a Goliat burlarse de su pueblo y de Dios. Esto hizo que David se sintiera muy triste y enojado.",
      "'Yo pelearé contra ese gigante', dijo David. El rey le ofreció su armadura, pero era muy pesada para David.",
      "David fue al río y recogió cinco piedras lisas. Solo llevaba su honda de pastor y su fe en Dios.",
      "Cuando Goliat vio a David, se rió. '¿Me envían a un niño?' Pero David no tuvo miedo.",
      "David puso una piedra en su honda, la giró y la lanzó. ¡La piedra golpeó a Goliat en la frente! El gigante cayó al suelo.",
      "David ganó la batalla, no por ser fuerte, sino porque confiaba en Dios. Todos celebraron su valentía.",
    ],
    lesson: "Con Dios a nuestro lado, podemos enfrentar cualquier desafío, sin importar qué tan grande parezca.",
    verse: '"El Señor es mi luz y mi salvación, ¿a quién temeré?" - Salmos 27:1',
  },
  "jonas-ballena": {
    title: "Jonás y la Ballena",
    image: "/jonah-inside-the-whale-children-bible-illustration.jpg",
    content: [
      "Dios le pidió a Jonás que fuera a la ciudad de Nínive para dar un mensaje importante. Pero Jonás no quería ir.",
      "En lugar de obedecer, Jonás se subió a un barco que iba en la dirección opuesta. Pensó que podía escapar de Dios.",
      "Mientras Jonás estaba en el barco, vino una tormenta terrible. Las olas eran enormes y el barco se sacudía mucho.",
      "Jonás sabía que la tormenta era por su culpa. Les dijo a los marineros: 'Tírenme al mar y la tormenta parará.'",
      "Los marineros no querían hacerlo, pero finalmente tuvieron que hacerlo. Cuando Jonás cayó al agua, la tormenta se calmó.",
      "Entonces, algo increíble pasó. Dios envió un pez gigante que se tragó a Jonás. ¡Jonás estuvo dentro del pez durante tres días y tres noches!",
      "Dentro del pez, Jonás oró a Dios y le pidió perdón. Dios escuchó su oración.",
      "El pez llevó a Jonás a la playa y lo escupió. Esta vez, Jonás obedeció a Dios y fue a Nínive a dar el mensaje.",
    ],
    lesson:
      "Es importante obedecer a Dios. Cuando nos equivocamos, podemos pedirle perdón y Él nos da otra oportunidad.",
    verse: '"Desde lo profundo clamé a ti, Señor, y tú me escuchaste." - Jonás 2:2',
  },
  "daniel-leones": {
    title: "Daniel y los Leones",
    image: "/daniel-praying-with-lions-around-him-children-illu.jpg",
    content: [
      "Daniel era un hombre muy sabio que trabajaba para el rey. Oraba a Dios tres veces al día.",
      "Algunos hombres celosos querían hacerle daño a Daniel. Convencieron al rey de hacer una ley: nadie podía orar a ningún dios excepto al rey durante 30 días.",
      "Daniel sabía de la nueva ley, pero siguió orando a Dios como siempre lo hacía. No tenía miedo.",
      "Los hombres celosos vieron a Daniel orando y se lo dijeron al rey. El rey estaba muy triste, pero tenía que cumplir su propia ley.",
      "Daniel fue arrojado a un foso lleno de leones hambrientos. El rey no pudo dormir esa noche, preocupado por Daniel.",
      "A la mañana siguiente, el rey corrió al foso y gritó: '¡Daniel! ¿Tu Dios te salvó?'",
      "Daniel respondió: '¡Sí, mi rey! Dios envió un ángel que cerró las bocas de los leones. No me hicieron daño porque soy inocente.'",
      "El rey estaba muy feliz. Sacó a Daniel del foso y castigó a los hombres malos. Desde ese día, el rey respetó al Dios de Daniel.",
    ],
    lesson: "Cuando somos fieles a Dios, Él nos protege incluso en las situaciones más peligrosas.",
    verse: '"Mi Dios envió su ángel y cerró la boca de los leones." - Daniel 6:22',
  },
  "moises-mar-rojo": {
    title: "Moisés y el Mar Rojo",
    image: "/moses-parting-the-red-sea-with-people-crossing-chi.jpg",
    content: [
      "El pueblo de Israel había sido esclavo en Egipto durante muchos años. Dios eligió a Moisés para liberarlos.",
      "Después de muchas señales milagrosas, el faraón finalmente dejó ir al pueblo de Israel. Todos estaban muy felices de ser libres.",
      "Pero el faraón cambió de opinión. Envió a su ejército con carros y caballos para traer de vuelta a los israelitas.",
      "El pueblo de Israel llegó al Mar Rojo. Había agua enfrente y el ejército egipcio detrás. ¡Estaban atrapados!",
      "La gente tenía mucho miedo, pero Moisés les dijo: 'No teman. Dios peleará por ustedes.'",
      "Moisés levantó su vara sobre el mar. Entonces pasó algo increíble: ¡el mar se abrió en dos! Apareció un camino seco en medio del agua.",
      "Todo el pueblo de Israel cruzó el mar caminando sobre tierra seca. Las aguas formaban paredes a cada lado.",
      "Cuando los egipcios intentaron seguirlos, Moisés volvió a levantar su vara. Las aguas regresaron y cubrieron al ejército. El pueblo de Israel estaba a salvo.",
    ],
    lesson:
      "Dios puede hacer lo imposible. Cuando confiamos en Él, nos muestra el camino incluso cuando parece que no hay salida.",
    verse: '"No teman. Quédense quietos y verán la salvación del Señor." - Éxodo 14:13',
  },
  "nacimiento-jesus": {
    title: "El Nacimiento de Jesús",
    image: "/nativity-scene-baby-jesus-mary-joseph-manger-child.jpg",
    content: [
      "Hace mucho tiempo, en un pueblo llamado Nazaret, vivía una joven llamada María. Era bondadosa y amaba a Dios.",
      "Un día, un ángel llamado Gabriel visitó a María. Le dijo: 'Vas a tener un bebé muy especial. Se llamará Jesús y será el Hijo de Dios.'",
      "María estaba comprometida con José, un carpintero bueno y trabajador. José también recibió un mensaje de un ángel en un sueño.",
      "El emperador ordenó que todos fueran a su ciudad natal para ser contados. María y José tuvieron que viajar a Belén.",
      "Cuando llegaron a Belén, no había lugar para quedarse. Todos los hoteles estaban llenos.",
      "Finalmente, encontraron un establo donde guardaban animales. Esa noche, María tuvo a su bebé. Lo envolvió en pañales y lo acostó en un pesebre.",
      "En los campos cercanos, unos pastores cuidaban sus ovejas. De repente, apareció un ángel brillante que les dijo: '¡Tengo buenas noticias! Hoy nació el Salvador en Belén.'",
      "Los pastores fueron rápidamente a Belén y encontraron a María, José y al bebé Jesús, tal como el ángel había dicho. Estaban llenos de alegría.",
      "También vinieron sabios del oriente siguiendo una estrella especial. Trajeron regalos de oro, incienso y mirra para el niño Jesús.",
    ],
    lesson:
      "Jesús vino al mundo para traer amor, esperanza y salvación a todas las personas. Es el mejor regalo de Dios.",
    verse: '"Hoy les ha nacido un Salvador, que es Cristo el Señor." - Lucas 2:11',
  },
}

export default function StoryDetailPage({ params }: { params: { id: string } }) {
  const story = storyContent[params.id]

  if (!story) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Historia no encontrada</h1>
          <Link href="/historias">
            <Button>Volver a Historias</Button>
          </Link>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Back Button */}
      <div className="container mx-auto max-w-4xl px-4 pt-8">
        <Link href="/historias">
          <Button variant="ghost" size="lg" className="gap-2 text-lg font-semibold hover:bg-white">
            <ArrowLeft className="h-5 w-5" />
            Volver a Historias
          </Button>
        </Link>
      </div>

      {/* Story Content */}
      <section className="px-4 py-8">
        <div className="container mx-auto max-w-4xl">
          <Card className="overflow-hidden border-4 border-white bg-white shadow-2xl">
            {/* Story Header */}
            <div className="bg-gradient-to-r from-blue-400 to-purple-400 px-8 py-12 text-center">
              <h1 className="mb-4 text-4xl font-bold text-white md:text-5xl text-balance drop-shadow-lg">
                {story.title}
              </h1>
            </div>

            {/* Story Image */}
            <div className="relative h-64 md:h-96 overflow-hidden">
              <img src={story.image || "/placeholder.svg"} alt={story.title} className="h-full w-full object-cover" />
            </div>

            {/* Story Text */}
            <div className="p-8 md:p-12">
              <div className="mb-8 flex items-center gap-2 text-blue-600">
                <BookOpen className="h-6 w-6" />
                <span className="text-xl font-semibold">La Historia</span>
              </div>

              <div className="space-y-6">
                {story.content.map((paragraph, index) => (
                  <p key={index} className="text-xl leading-relaxed text-gray-700">
                    {paragraph}
                  </p>
                ))}
              </div>

              {/* Lesson Section */}
              <Card className="mt-12 border-4 border-yellow-200 bg-gradient-to-br from-yellow-50 to-orange-50 p-8">
                <div className="mb-4 flex items-center gap-2 text-orange-600">
                  <Heart className="h-6 w-6 fill-orange-600" />
                  <span className="text-2xl font-bold">¿Qué Aprendemos?</span>
                </div>
                <p className="mb-6 text-xl leading-relaxed text-gray-800">{story.lesson}</p>
                <div className="rounded-xl bg-white p-6 shadow-md">
                  <p className="text-center text-lg font-semibold italic text-gray-700">{story.verse}</p>
                </div>
              </Card>

              {/* Action Buttons */}
              <div className="mt-12 flex flex-wrap justify-center gap-4">
                <Link href="/historias">
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-2 border-blue-400 text-blue-600 hover:bg-blue-50 text-lg px-8 py-6 rounded-full bg-transparent"
                  >
                    Leer Otra Historia
                  </Button>
                </Link>
                <Link href="/colorear">
                  <Button
                    size="lg"
                    className="bg-orange-500 text-white hover:bg-orange-600 text-lg px-8 py-6 rounded-full shadow-lg"
                  >
                    Colorear Esta Historia
                  </Button>
                </Link>
              </div>
            </div>
          </Card>
        </div>
      </section>
    </div>
  )
}
