import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight, Star } from "lucide-react"

const stories = [
  {
    id: "noe-arca",
    title: "Noé y el Arca",
    description: "Descubre cómo Noé construyó un arca gigante para salvar a los animales del gran diluvio.",
    image: "/noah-s-ark-with-animals-colorful-children-illustra.jpg",
    color: "from-blue-400 to-cyan-300",
    difficulty: "Fácil",
  },
  {
    id: "david-goliat",
    title: "David y Goliat",
    description: "La historia del valiente David que venció al gigante Goliat con su fe y una honda.",
    image: "/david-and-goliath-children-bible-story-illustratio.jpg",
    color: "from-green-400 to-emerald-300",
    difficulty: "Fácil",
  },
  {
    id: "jonas-ballena",
    title: "Jonás y la Ballena",
    description: "Jonás fue tragado por una ballena gigante. ¿Qué pasó después?",
    image: "/jonah-and-the-whale-colorful-children-illustration.jpg",
    color: "from-purple-400 to-pink-300",
    difficulty: "Fácil",
  },
  {
    id: "daniel-leones",
    title: "Daniel y los Leones",
    description: "Daniel fue arrojado a un foso de leones, pero Dios lo protegió.",
    image: "/daniel-in-the-lions-den-children-bible-illustratio.jpg",
    color: "from-orange-400 to-yellow-300",
    difficulty: "Media",
  },
  {
    id: "moises-mar-rojo",
    title: "Moisés y el Mar Rojo",
    description: "Moisés abrió el Mar Rojo para que su pueblo pudiera cruzar a salvo.",
    image: "/moses-parting-the-red-sea-children-illustration.jpg",
    color: "from-blue-500 to-teal-300",
    difficulty: "Media",
  },
  {
    id: "nacimiento-jesus",
    title: "El Nacimiento de Jesús",
    description: "La hermosa historia de cómo nació Jesús en Belén.",
    image: "/nativity-scene-baby-jesus-children-illustration.jpg",
    color: "from-yellow-400 to-orange-300",
    difficulty: "Fácil",
  },
]

export default function HistoriasPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Header */}
      <section className="bg-gradient-to-r from-blue-400 to-purple-400 px-4 py-16">
        <div className="container mx-auto max-w-6xl text-center">
          <h1 className="mb-4 text-5xl font-bold text-white md:text-6xl text-balance drop-shadow-lg">
            Historias Bíblicas
          </h1>
          <p className="text-xl text-white md:text-2xl text-balance max-w-3xl mx-auto leading-relaxed drop-shadow">
            Elige una historia para leer y aprender
          </p>
        </div>
      </section>

      {/* Stories Grid */}
      <section className="px-4 py-16">
        <div className="container mx-auto max-w-6xl">
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {stories.map((story) => (
              <Link key={story.id} href={`/historias/${story.id}`} className="group">
                <Card className="h-full overflow-hidden border-4 border-white bg-white shadow-lg transition-all hover:scale-105 hover:shadow-2xl">
                  {/* Story Image */}
                  <div className={`relative h-48 bg-gradient-to-br ${story.color} overflow-hidden`}>
                    <img
                      src={story.image || "/placeholder.svg"}
                      alt={story.title}
                      className="h-full w-full object-cover transition-transform group-hover:scale-110"
                    />
                    <div className="absolute top-3 right-3 flex items-center gap-1 bg-white px-3 py-1 rounded-full shadow-md">
                      <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                      <span className="text-sm font-semibold text-gray-700">{story.difficulty}</span>
                    </div>
                  </div>

                  {/* Story Content */}
                  <div className="p-6">
                    <h3 className="mb-3 text-2xl font-bold text-gray-800 group-hover:text-blue-600 transition-colors">
                      {story.title}
                    </h3>
                    <p className="mb-4 text-lg text-gray-600 leading-relaxed">{story.description}</p>

                    <div className="flex items-center gap-2 text-blue-600 font-semibold group-hover:gap-3 transition-all">
                      <span>Leer Historia</span>
                      <ArrowRight className="h-5 w-5" />
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-gradient-to-r from-yellow-100 to-orange-100 px-4 py-16">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="mb-4 text-3xl font-bold text-gray-800 md:text-4xl">¿Terminaste de Leer?</h2>
          <p className="mb-8 text-xl text-gray-700 leading-relaxed">
            ¡Mira videos divertidos o descarga libros para colorear!
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/videos">
              <Button
                size="lg"
                className="bg-green-500 text-white hover:bg-green-600 text-xl px-8 py-6 rounded-full shadow-lg"
              >
                Ver Videos
              </Button>
            </Link>
            <Link href="/colorear">
              <Button
                size="lg"
                className="bg-orange-500 text-white hover:bg-orange-600 text-xl px-8 py-6 rounded-full shadow-lg"
              >
                Libros para Colorear
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
