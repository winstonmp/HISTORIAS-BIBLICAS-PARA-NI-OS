"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Download, Printer, FileText } from "lucide-react"
import { useState } from "react"

const coloringBooks = [
  {
    id: "noe-arca-colorear",
    title: "Noé y el Arca",
    description: "Colorea a Noé, el arca y todos los animales",
    preview: "/noah-ark-coloring-page-preview.jpg",
    pages: 8,
    difficulty: "Fácil",
    pdfUrl: "/coloring-books/noe-arca.pdf",
  },
  {
    id: "david-goliat-colorear",
    title: "David y Goliat",
    description: "Colorea la batalla entre David y el gigante Goliat",
    preview: "/david-goliath-coloring-page-preview.jpg",
    pages: 6,
    difficulty: "Media",
    pdfUrl: "/coloring-books/david-goliat.pdf",
  },
  {
    id: "jonas-ballena-colorear",
    title: "Jonás y la Ballena",
    description: "Colorea a Jonás dentro de la ballena gigante",
    preview: "/jonah-whale-coloring-page-preview.jpg",
    pages: 5,
    difficulty: "Fácil",
    pdfUrl: "/coloring-books/jonas-ballena.pdf",
  },
  {
    id: "daniel-leones-colorear",
    title: "Daniel y los Leones",
    description: "Colorea a Daniel con los leones en el foso",
    preview: "/daniel-lions-coloring-page-preview.jpg",
    pages: 7,
    difficulty: "Media",
    pdfUrl: "/coloring-books/daniel-leones.pdf",
  },
  {
    id: "moises-mar-rojo-colorear",
    title: "Moisés y el Mar Rojo",
    description: "Colorea el momento cuando Moisés abre el mar",
    preview: "/moses-red-sea-coloring-page-preview.jpg",
    pages: 6,
    difficulty: "Media",
    pdfUrl: "/coloring-books/moises-mar-rojo.pdf",
  },
  {
    id: "nacimiento-jesus-colorear",
    title: "El Nacimiento de Jesús",
    description: "Colorea el pesebre y la historia de Navidad",
    preview: "/nativity-coloring-page-preview.jpg",
    pages: 10,
    difficulty: "Fácil",
    pdfUrl: "/coloring-books/nacimiento-jesus.pdf",
  },
  {
    id: "adan-eva-colorear",
    title: "Adán y Eva",
    description: "Colorea el jardín del Edén con Adán y Eva",
    preview: "/adam-eve-garden-coloring-page-preview.jpg",
    pages: 5,
    difficulty: "Fácil",
    pdfUrl: "/coloring-books/adan-eva.pdf",
  },
  {
    id: "milagros-jesus-colorear",
    title: "Los Milagros de Jesús",
    description: "Colorea los increíbles milagros que hizo Jesús",
    preview: "/jesus-miracles-coloring-page-preview.jpg",
    pages: 12,
    difficulty: "Media",
    pdfUrl: "/coloring-books/milagros-jesus.pdf",
  },
]

export default function ColorearPage() {
  const [downloadingId, setDownloadingId] = useState<string | null>(null)

  const handleDownload = (book: (typeof coloringBooks)[0]) => {
    setDownloadingId(book.id)
    // Simulate download
    setTimeout(() => {
      setDownloadingId(null)
      alert(`¡Descargando "${book.title}"! El archivo PDF se guardará en tu dispositivo.`)
    }, 1000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-pink-50 to-purple-50">
      {/* Header */}
      <section className="bg-gradient-to-r from-orange-400 to-pink-400 px-4 py-16">
        <div className="container mx-auto max-w-6xl text-center">
          <h1 className="mb-4 text-5xl font-bold text-white md:text-6xl text-balance drop-shadow-lg">
            Libros para Colorear
          </h1>
          <p className="text-xl text-white md:text-2xl text-balance max-w-3xl mx-auto leading-relaxed drop-shadow">
            Descarga e imprime dibujos de tus historias favoritas
          </p>
        </div>
      </section>

      {/* Instructions */}
      <section className="px-4 py-12">
        <div className="container mx-auto max-w-6xl">
          <Card className="border-4 border-orange-200 bg-gradient-to-br from-yellow-50 to-orange-50 p-8">
            <h2 className="mb-6 text-center text-3xl font-bold text-gray-800">¿Cómo Usar los Libros?</h2>
            <div className="grid gap-6 md:grid-cols-3">
              <div className="text-center">
                <div className="mb-4 flex justify-center">
                  <div className="rounded-full bg-orange-400 p-4">
                    <Download className="h-8 w-8 text-white" />
                  </div>
                </div>
                <h3 className="mb-2 text-xl font-bold text-gray-800">1. Descarga</h3>
                <p className="text-lg text-gray-600">Haz clic en el botón de descarga del libro que te guste</p>
              </div>
              <div className="text-center">
                <div className="mb-4 flex justify-center">
                  <div className="rounded-full bg-pink-400 p-4">
                    <Printer className="h-8 w-8 text-white" />
                  </div>
                </div>
                <h3 className="mb-2 text-xl font-bold text-gray-800">2. Imprime</h3>
                <p className="text-lg text-gray-600">Pídele a un adulto que imprima las páginas</p>
              </div>
              <div className="text-center">
                <div className="mb-4 flex justify-center">
                  <div className="rounded-full bg-purple-400 p-4">
                    <FileText className="h-8 w-8 text-white" />
                  </div>
                </div>
                <h3 className="mb-2 text-xl font-bold text-gray-800">3. Colorea</h3>
                <p className="text-lg text-gray-600">Usa tus colores favoritos y diviértete</p>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Coloring Books Grid */}
      <section className="px-4 pb-16">
        <div className="container mx-auto max-w-6xl">
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {coloringBooks.map((book) => (
              <Card
                key={book.id}
                className="group h-full overflow-hidden border-4 border-white bg-white shadow-lg transition-all hover:scale-105 hover:shadow-2xl"
              >
                {/* Preview Image */}
                <div className="relative h-64 overflow-hidden bg-gradient-to-br from-orange-100 to-pink-100">
                  <img
                    src={book.preview || "/placeholder.svg"}
                    alt={book.title}
                    className="h-full w-full object-cover transition-transform group-hover:scale-110"
                  />

                  {/* Difficulty Badge */}
                  <div className="absolute top-3 right-3 bg-white px-3 py-1 rounded-full shadow-md">
                    <span className="text-sm font-semibold text-gray-700">{book.difficulty}</span>
                  </div>

                  {/* Pages Badge */}
                  <div className="absolute top-3 left-3 bg-orange-500 px-3 py-1 rounded-full shadow-md">
                    <span className="text-sm font-semibold text-white">{book.pages} páginas</span>
                  </div>
                </div>

                {/* Book Info */}
                <div className="p-6">
                  <h3 className="mb-3 text-2xl font-bold text-gray-800">{book.title}</h3>
                  <p className="mb-6 text-lg text-gray-600 leading-relaxed">{book.description}</p>

                  <Button
                    onClick={() => handleDownload(book)}
                    disabled={downloadingId === book.id}
                    size="lg"
                    className="w-full bg-orange-500 text-white hover:bg-orange-600 text-lg py-6 rounded-full shadow-lg gap-2"
                  >
                    {downloadingId === book.id ? (
                      <>
                        <div className="h-5 w-5 animate-spin rounded-full border-2 border-white border-t-transparent" />
                        Descargando...
                      </>
                    ) : (
                      <>
                        <Download className="h-5 w-5" />
                        Descargar PDF
                      </>
                    )}
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Tips Section */}
      <section className="bg-gradient-to-r from-blue-100 to-green-100 px-4 py-16">
        <div className="container mx-auto max-w-4xl">
          <h2 className="mb-8 text-center text-3xl font-bold text-gray-800 md:text-4xl">Consejos para Colorear</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="border-2 border-blue-200 bg-white p-6">
              <h3 className="mb-3 text-xl font-bold text-blue-600">Usa Diferentes Colores</h3>
              <p className="text-lg text-gray-600 leading-relaxed">
                No tengas miedo de usar muchos colores. ¡Haz que tus dibujos sean únicos y especiales!
              </p>
            </Card>
            <Card className="border-2 border-green-200 bg-white p-6">
              <h3 className="mb-3 text-xl font-bold text-green-600">Tómate Tu Tiempo</h3>
              <p className="text-lg text-gray-600 leading-relaxed">
                No hay prisa. Colorear es relajante y divertido. Disfruta cada momento.
              </p>
            </Card>
            <Card className="border-2 border-purple-200 bg-white p-6">
              <h3 className="mb-3 text-xl font-bold text-purple-600">Comparte con la Familia</h3>
              <p className="text-lg text-gray-600 leading-relaxed">
                Colorear es más divertido con amigos y familia. ¡Invítalos a colorear contigo!
              </p>
            </Card>
            <Card className="border-2 border-orange-200 bg-white p-6">
              <h3 className="mb-3 text-xl font-bold text-orange-600">Muestra Tu Arte</h3>
              <p className="text-lg text-gray-600 leading-relaxed">
                Cuando termines, muestra tu dibujo a tus padres. ¡Pueden ponerlo en el refrigerador!
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="px-4 py-16">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="mb-4 text-3xl font-bold text-gray-800 md:text-4xl">¿Quieres Más Diversión?</h2>
          <p className="mb-8 text-xl text-gray-700 leading-relaxed">
            Lee las historias completas o mira videos animados
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button
              size="lg"
              className="bg-blue-500 text-white hover:bg-blue-600 text-xl px-8 py-6 rounded-full shadow-lg"
              onClick={() => (window.location.href = "/historias")}
            >
              Leer Historias
            </Button>
            <Button
              size="lg"
              className="bg-green-500 text-white hover:bg-green-600 text-xl px-8 py-6 rounded-full shadow-lg"
              onClick={() => (window.location.href = "/videos")}
            >
              Ver Videos
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
