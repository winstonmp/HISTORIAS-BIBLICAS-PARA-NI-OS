import type React from "react"
import type { Metadata } from "next"
import { Fredoka } from "next/font/google"
import "./globals.css"
import { Navigation } from "@/components/navigation"

const fredoka = Fredoka({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-sans",
})

export const metadata: Metadata = {
  title: "Historias Bíblicas para Niños",
  description:
    "Descubre historias bíblicas, videos divertidos y libros para colorear diseñados especialmente para niños",
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es" className={fredoka.variable}>
      <body>
        <Navigation />
        <main>{children}</main>
        <footer className="border-t-4 border-blue-200 bg-gradient-to-r from-blue-50 to-cyan-50 px-4 py-12">
          <div className="container mx-auto max-w-6xl text-center">
            <p className="text-xl font-semibold text-gray-700 mb-4">Historias Bíblicas para Niños</p>
            <p className="text-lg text-gray-600">Contenido seguro y educativo para toda la familia</p>
            <p className="mt-6 text-sm text-gray-500">© 2025 Todos los derechos reservados</p>
          </div>
        </footer>
      </body>
    </html>
  )
}
